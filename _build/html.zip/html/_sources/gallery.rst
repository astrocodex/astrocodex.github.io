Python Exercises Gallery
========================

.. gallery:: exercises.json